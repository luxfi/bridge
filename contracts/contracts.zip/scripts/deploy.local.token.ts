import { ethers } from "hardhat";

async function main() {
    const name = "CYRUS"

    const [deployer] = await ethers.getSigners()
    console.log(">> deployer Address ", deployer.address)

    // Get the current nonce of the signer
    const nonce = await deployer.getNonce()
    console.log(">> current Nonce ", nonce)

    return

    const bridge = '0x9012A4162deA268F6a9e475b78B33f20127158E3'
    const singer = '0x254CDEBF0A640ffdAA3BF00a52954772436a3aD0'
    /////Z
    const _signer = await ethers.getContractFactory(name);
    const token = await _signer.deploy();
    const address = await token.getAddress()
    console.log(`>> ${name} address `, await token.getAddress());

    //deploy
    const tokenContract = await ethers.getContractAt(name, address)
    
    const txBridge = await tokenContract.grantAdmin(bridge)
    await txBridge.wait()
    console.log(`>> ${name}'s admin is set as bridge `, txBridge.hash)

    const txUtila = await tokenContract.grantAdmin(singer)
    await txUtila.wait()
    console.log(`>> ${name}'s admin is set as utila minter `, txUtila.hash)
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
